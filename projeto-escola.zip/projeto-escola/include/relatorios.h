#ifndef RELATORIOS_H
#define RELATORIOS_H

#include "funcoes.h"

void ListarAlunos(Aluno alunos[], int qtdAlunos);
void ExibirMenuRelatorios(Aluno alunos[], int qtdAlunos, Professor professores[], int qtdProfessores, Disciplina disciplinas[], int qtdDisciplinas);

#endif
