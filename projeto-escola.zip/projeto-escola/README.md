# Projeto Escola 📘

Este projeto simula o gerenciamento de alunos, professores e disciplinas em uma escola, com funções para cadastro, matrícula e geração de relatórios.

## 📂 Estrutura do Projeto

- `src/`: Código-fonte do projeto.
- `include/`: Arquivos de cabeçalho (headers).
- `Makefile`: Script de compilação automatizada.
- `programa`: Binário gerado.

## 🔧 Compilação

Para compilar o projeto:

```bash
make
```

Para rodar:

```bash
make run
```

Para limpar os arquivos gerados:

```bash
make clean
```
